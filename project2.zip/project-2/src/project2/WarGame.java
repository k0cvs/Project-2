package project2;



public class WarGame extends ConsoleProgram
{
	
	
	public static void main(String[] args) 
	{
		int hailMary = 0;
	    int enemyRecruit = 0;
		ConsoleProgram a1 = new ConsoleProgram();
		System.out.println("Welcome to War!");
        System.out.println("Once all of your soldiers die or you have killed all of the enemy soldiers, you will be returned to the choice of how many soldiers you want.");
        System.out.println();
        String name = a1.readLine("Please enter your name ---> ");
        System.out.println();
        
        while(true)
        {
            hailMary = 0;
            enemyRecruit = 0;
            int soldiers = a1.readInt("Ok, " + name + " enter number of soldiers you want to start with ---> ");
            dice dice = new dice();
            dice.rollDice();
            int enemy = dice.getRoll();
            System.out.println();
            System.out.println("You will be facing off against " + enemy + " enemies!");
            System.out.println();
            System.out.println();
            System.out.println("Let the carnage begin!");
            System.out.println();
            System.out.println();
            War war = new War(name, soldiers, enemy);
            
            dice dice2 = new dice();
            dice2.rollDice();
            if(dice2.getRoll() < 25)
            {
                System.out.println("Aren't you lucky. Your enemy is stupid and forgot to hide. You get an extra first attack!");
                System.out.println();
                war.attackChoice();
                System.out.println("Attacking enemy with " +  war.attackChoices[war.choice]);
                war.bonuses();
                war.setEnemy(war.bonus);
                System.out.println();
                System.out.println();
                System.out.println("Your bonus attack killed " + war.bonus + " enemies. There are now  " + war.getEnemy() + " enemies left");
                System.out.println();
            }
            
            
            
            while(war.getSoldiers() != 0 || war.getEnemy() !=0)
            {
            Fire fire = new Fire();
            dice dice3 = new dice();
            war.attackChoice();
            System.out.println("Attacking enemy with " +  war.attackChoices[war.choice]);
            System.out.println();
            System.out.println();
            System.out.println("Your attack killed " + war.killedEnem() + " enemies!");
            war.setEnemy(war.killede);
            System.out.println("There are " + war.getEnemy() + " enemies left!");
            
            if(war.getEnemy() <= 0)
            {
                System.out.println();
                System.out.println();
                System.out.println(fire.victory());
                System.out.println("You have killed all your enemies and still have " + war.getSoldiers() + " soldiers left. Lets play again!");
                System.out.println();
                System.out.println();
                break;
            }
            
            if(war.getEnemy() < 10 && war.getEnemy() > 0)
            {
                dice3.rollDice();
                
                if(enemyRecruit > 0)
                {
                    System.out.println();
                    System.out.println();
                    continue;
                }
                
                if(dice3.getRoll() > 10)
                {
                    System.out.println();
                    System.out.println();
                    war.enemyRecruit();
                    enemyRecruit = enemyRecruit + 1;
                    System.out.println("Oh dear. It appears that your enemy has forcibly conscripted " + war.enemRecruit + " soldiers. There are now " + war.getEnemy() + " enemies left!");
                    System.out.println();
                    System.out.println();
                }    
            }
            
            System.out.println();
            System.out.println();
            System.out.println("It is now your enemies turn to attack!");
            System.out.println();
            System.out.println("Your enemy attacks you with " +  war.attackChoices[war.generateRandomNum(10)]);
            System.out.println("Your enemy killed " + war.killedSol() + " of your soldiers!");
            war.setSoldiers(war.killeda);
            
            if(war.killeda > 0)
            {
                System.out.println("Your dieing soldiers scream " + war.deathMessage());
            }
            
            System.out.println("You have " + war.getSoldiers() + " soldiers left!");
            
            
            if(war.getSoldiers() < 10 && war.getSoldiers() > 0)
            {
                if(hailMary > 0)
                {
                    System.out.println();
                    System.out.println();
                    continue;
                    
                }
                
                System.out.println();
                System.out.println();
                boolean recruiting = a1.readBoolean("You are running low on soldiers. Would you like to try an emergency recruitment drive? You can only do this ONCE per game. (true/false) --> ");
                if(recruiting)
                {
                    System.out.println();
                    System.out.println();
                    war.recruit();
                    System.out.println("Congratulaions! You successfully recruited " + war.recruit + " new soldiers. You now have " + war.getSoldiers() + " soldiers.");
                    hailMary = hailMary + 1;
                    
                }
                else if(!recruiting)
                {
                    System.out.println();
                    System.out.println();
                    System.out.println("Ok then. Good luck!");
                }
            }
            
            
            
            if(war.getSoldiers() <=0)
            {
                System.out.println();
                System.out.println();
                System.out.println(fire.defeat());
                System.out.println("All of your soldiers have died! The enemy still had  "  + war.getEnemy() + "  enemies left. Lets play again.");
                System.out.println();
                System.out.println();
                break;
            }
            
            System.out.println();
            System.out.println();
            }
            continue;
         
            
        }

	}

}
