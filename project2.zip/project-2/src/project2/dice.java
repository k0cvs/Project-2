package project2;

import java.util.Random;

public class dice
{
    private int roll;
    
    dice()
    {
        roll = 0;
    }
    
    public int getRoll()
    {
        return roll;
    }
    
    public void rollDice()
    {
        
        this.roll = generateRandomNum();
        
    }
    
    public int generateRandomNum()
    {
        Random rand = new Random(); //instance of random class
        //generate random values from 1-100
        int randomNumber = 1 + rand.nextInt(99);
        //double double_random=rand.nextDouble();
        
        return randomNumber;
    }
}
