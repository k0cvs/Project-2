package project2;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

public class War extends Gameplay
{
	
    int choice = 0;
    
    War(String name, int soldiers, int enemy)
    {
        super(name, soldiers, enemy);
    }
    
    public String deathMessage()
    {
        String[] deathMessages = new String[10];
        
        try
        {
            FileReader fileReader = new FileReader("deathMessage.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            deathMessages[0] = bufferedReader.readLine();
            deathMessages[1] = bufferedReader.readLine();
            deathMessages[2] = bufferedReader.readLine();
            deathMessages[3] = bufferedReader.readLine();
            deathMessages[4] = bufferedReader.readLine();
            deathMessages[5] = bufferedReader.readLine();
            deathMessages[6] = bufferedReader.readLine();
            deathMessages[7] = bufferedReader.readLine();
            deathMessages[8] = bufferedReader.readLine();
            deathMessages[9] = bufferedReader.readLine();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        int randomDeath = 1 + generateRandomNum(9);
        return deathMessages[randomDeath];
    }
    
    
    
    public int attackChoice()
    {
        
        while(true)
        {
        System.out.println("Here is Your inventory of attacks: ");
        for(int i = 0; i < attackCount; i++)
        {
            System.out.println("\tAttack " + i + ": "  + attackChoices[i]);
            
        }
        System.out.println();
        choice = readInt("Please Choose attack number: ");
        if(choice > 9)
        {
             System.out.println();
             System.out.println("No dummy! You can only choose 0-9. Try again!");
             System.out.println();
             continue;
        }
          return choice;
        }
        
    }
   
}