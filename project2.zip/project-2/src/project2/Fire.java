package project2;

public class Fire
{
    Fire()
    {
        
    }
    
    
  
    public String victory()
    {
       return "You stand victorious!";
    }
    
    
    
    public String defeat()
    {
        return "You you have been conquored and your lands pillaged!";
    }
}