package project2;



/*
I know that the file name makes no sense but I created it with another purpose in mind
that just didnt pan out so i repurposed it. couldnt change the name without having
to rewrite everything else
*/

public class Fire 
{
    
    //Constructor for fire
    Fire()
    {
        
    }
    
    
    //Returns victory message to game
    public String victory()
    {
       return "You stand victorious!";
    }
    
    
    //Returns defeat message to game
    public String defeat()
    {
        return "You you have been conquored and your lands pillaged!";
    }
    
    
    
    
    
}




//ConsoleProgram a1 = new ConsoleProgram();