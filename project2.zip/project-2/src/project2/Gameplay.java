package project2;

import java.util.Random;


public class Gameplay extends ConsoleProgram
{
    private String name;
    private int soldiers;
    private int enemy;
    int killede = 0;
    int killeda = 0;
    int recruit = 0;
    int bonus = 0;
    int enemRecruit = 0;
    
    ConsoleProgram a1 = new ConsoleProgram();
    Gameplay(String name, int soldiers, int enemy)
    {
        this.name = name;
        this.soldiers = soldiers;
        this.enemy = enemy;
    }
    
    String attackChoices [] = {"Tanks", "Planes", "Infantry", "Guns", "Swords", "Daggers", "Tear Gas", "Napalm", "Nukes", "CyberAttack"};
    int attackCount = attackChoices.length;
    
   public int generateRandomNum(int upperLimit)
    {
        //instance of random class
        //generate random values from 0 to upperLimit
        Random rand = new Random(); 
        int randomNumber = rand.nextInt(upperLimit);
        
        return randomNumber;
    } 
    
    public int killedEnem()
    {
        killede = 1 +generateRandomNum(enemy);
        return killede;
    }
    
    public int killedSol()
    {
        killeda = 1 + generateRandomNum(soldiers);
        return killeda;
    }
    
    
    public int recruit()
    {
        recruit = 1 + generateRandomNum(25);
        soldiers = soldiers + recruit;
        return recruit;
        
    }
    
    public int bonuses()
    {
        bonus = killedEnem();
        return bonus;
    }
    
    public int enemyRecruit()
    {
        enemRecruit = 1 + generateRandomNum(25);
        enemy = enemy + enemRecruit;
        return enemRecruit;
        
    }
    
    //Getters & Setters below
    //
    //
    //
    //
    
    
    public void setEnemy(int killedEnemey)
    {
        enemy = enemy - killede;
    }
    
    
    public void setSoldiers(int killedSoldiers)
    {
        soldiers = soldiers - killeda;
    }
    
    
    public int getEnemy()
    {
        return enemy;
    }
    
    public int getSoldiers()
    {
        return soldiers;
    }
}